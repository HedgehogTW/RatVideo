The simplest way to use this project.

1 - Install Qt SDK ( Qt Creator IDE and Qt 5.0 framework )
    for your operating system.

2 - Open file Ofeli.pro with Qt Creator.

3 - Execute qmake in order to generate a makefile with Qt Creator.

4 - Compile and run with Qt Creator.